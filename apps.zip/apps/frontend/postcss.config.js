const postCSSConfig = require('../../libs/ui/postcss.config');
module.exports = postCSSConfig;
