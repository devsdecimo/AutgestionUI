const actionsEN = {
    mainTitle: 'Personal Actions',
    searchOptions: 'Search Options',
    personalActionType: 'Personal Action Type',
    startDate: 'Start Date',
    endDate: 'End Date',
    search: 'Search',
    personalActionNumber: 'Personal Action Number',
    personalActionState: 'Personal Action State',
    registerDate: 'Register Date',
    effectiveDate: 'Effective Date',
    remarks: 'Remarks',
    fortnightly: 'Fortnightly',
    monthly: 'Monthly',
}

export default actionsEN;