const addtionalIdentificationsEN = {
    recordButton: 'Record',
    identificationButton: 'Identifications',
    referencesButton: 'References',

    maintitle: 'Additional Identifications',
    identificationType: 'Identification Type',
    identificationNumber: 'Identification Number',
    
}

export default addtionalIdentificationsEN;