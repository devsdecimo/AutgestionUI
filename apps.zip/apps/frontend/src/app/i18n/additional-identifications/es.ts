const addtionalIdentificationsES = {
    recordButton: 'Expediente',
    identificationButton: 'Identificaciones',
    referencesButton: 'Referencias',
    
    maintitle: 'Identificaciones Adicionales',

    identificationType: 'Tipo de Identificación',
    identificationNumber: 'Número de Identificación',
    
}

export default addtionalIdentificationsES;