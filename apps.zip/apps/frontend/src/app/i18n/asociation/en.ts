const asociationEN = {
  title: 'Employee Association',
  entityLabel: 'Entity',
  percentageLabel: 'Percentage',
  entryDateLabel: 'Entry Date',
};

export default asociationEN;
