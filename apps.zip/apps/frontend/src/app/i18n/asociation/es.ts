const asociationES = {
  title: 'Asociación de Empleado',
  entityLabel: 'Entidad',
  percentageLabel: 'Porcentaje',
  entryDateLabel: 'Fecha de ingreso',
};

export default asociationES;
