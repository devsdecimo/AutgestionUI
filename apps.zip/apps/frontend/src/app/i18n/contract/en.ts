const contractEN = {
    contractBtn: 'Contract',
    asociationBtn: 'Asociation',
    orgLocationBtn: 'Organization Location',
    payMethodBtn: 'Payment Method and Salary Composition',
    contractInfo: 'Contract Info',
    contractName: 'Contract Name',
    contractOpeningDate: 'Opening Date',
    contractType: 'Type',
    contractNumber: 'Contract Number',
    generalInfo: 'General Info',
    contractPosition: 'Position',
    contractStatus: 'Contract Status',
    schedule: 'Established schedule',
  };
  
  export default contractEN;