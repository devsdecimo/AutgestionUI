const contractES = {
    contractBtn: 'Contrato',
    asociationBtn: 'Asociación',
    orgLocationBtn: 'Ubicación de la Organización',
    payMethodBtn: 'Forma de Pago y Composición Salarial',
    contractInfo: 'Información de Contrato',
    contractName: 'Nombre de Contrato',
    contractOpeningDate: 'Fecha de Apertura',
    contractType: 'Tipo',
    contractNumber: 'Número de Contrato',
    generalInfo: 'Información General',
    contractPosition: 'Puesto',
    contractStatus: 'Estado de Contrato',
    schedule: 'Horario Establecido',
  };

  export default contractES;
