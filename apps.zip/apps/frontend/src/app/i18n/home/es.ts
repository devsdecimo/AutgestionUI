const homeES = {
    title: 'Información General',
    person: {
      title: 'Persona',
      header1: 'Puesto',
      header2: 'Salario Base',
      header3: 'Horario'
    },
    contract: {
      title: 'Contrato',
      header1: 'Número de Contrato',
      header2: 'Estado',
      header3: 'Fecha de Apertura'
    },
    record: {
      title: 'Expediente',
      header1: 'Número de Expediente',
      header2: 'Código de Empleado',
      header3: 'Fecha de Apertura'
    },
    buttonText: 'Ver Detalles'

  };

  export default homeES;
