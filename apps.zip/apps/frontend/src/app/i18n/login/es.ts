const loginES = {
    username: 'Nombre de usuario',
    password: 'Contraseña',
    insertUsername: 'Ingresar Nombre de Usuario',
    insertPassword: 'Ingresar Contraseña',
    submit: 'Entrar',
    confidentialityTerms:
      '*Le recordamos que la información de beneficios internos y monetarios es confidencial, los datos aquí consultados son personales por tanto no debe compartirlos con nadie.',
    acceptConfidentialityTerms: 'Acepto los términos de confidencialidad',
    forgotPassword: 'Olvidé mi contraseña',
  };
  
  export default loginES;