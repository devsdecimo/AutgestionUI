const organizationLocationEN = {
  title: "Organization Location",
  description: "Description",
  percentage: "Participation Percentage",
};

export default organizationLocationEN;
