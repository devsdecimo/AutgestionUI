const organizationLocationES = {
  title: "Ubicación de la Organización",
  description: "Descripción",
  percentage: "Porcentaje de Participación",
};

export default organizationLocationES;
