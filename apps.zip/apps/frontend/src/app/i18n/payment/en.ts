const paymentEN = {
    titlePaymentMethod: 'Payment Method',
    titleSalaryComposition: 'Composición Salarial',
    labels: {
      paymentMethod: 'Payment Method',
      bank: 'Bank',
      currency: 'Currency',
      account: 'Account',
      concept: 'Concept',
      percentage: 'Percentage',
      unit: 'Payment Unit',
      value: 'Value',
    }
};

  export default paymentEN;
