const permissionsCreateEN = {
    applicationBtn: 'Permissions Aplication',
    resolutionBtn: 'Resolution of Permit Applications',
    mainTitle: 'Permissions Aplication',
    createApplication: 'Create Application',
    personalActionType: 'Personal Action Type',
    time: 'Time',
    startDate: 'Start Date',
    reentryDate: 'Reentry Date',
    justification: 'Justification',
    boxLabel: 'Drag or Click this box to upload a file.',
    uploadFileLabel: 'Upload File',
    sendApplication: 'Send Application',
    stateLabel: 'of 1 file uploaded',
    cancelBtnLabel:'Cancel',
    saveBtnLabel: 'Upload',
    alertSuccessTitle: 'File Uploaded',
    alertSuccessText: 'File Uploaded Successfully',
}

export default permissionsCreateEN;
