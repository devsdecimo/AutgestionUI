const personalReferencesEN = {
    recordButton: 'Record',
    identificationButton: 'Identifications',
    referencesButton: 'References',
    maintitle: 'Personal References',
    reference: 'Reference',
    phoneNumber: 'Phone Number',
    description: 'Description',
  };
  
  export default personalReferencesEN;