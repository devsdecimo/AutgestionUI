const personalReferencesEN = {
    recordButton: 'Expediente',
    identificationButton: 'Identificaciones',
    referencesButton: 'Referencias',
    maintitle: 'Referencias Personales',
    reference: 'Referencia',
    phoneNumber: 'Teléfono',
    description: 'Descripción',
  };
  
  export default personalReferencesEN;