const profileEN = {
  title: 'Profile',
  name: 'Name',
  user: 'User',
  email: 'Email',
  password: 'Password',
  edit: 'Edit',
  save: 'Save',
  birthday: 'Date of Birth',
  province: 'Province',
  canton: 'Canton',
  district: 'District',
  postalCode: 'Postal Code',
  country: 'Country'
};

export default profileEN;
