const profileES = {
    title: 'Perfil',
    name: 'Nombre',
    user: 'Usuario',
    email: 'Correo Electrónico',
    password: 'Contraseña',
    edit: 'Editar',
    save: 'Guardar',
    birthday: 'Fecha de Nacimiento',
    province: 'Provincia',
    canton: 'Cantón',
    district: 'Distrito',
    zipCode: 'Código Postal',
    country: 'País'
  };

  export default profileES;
