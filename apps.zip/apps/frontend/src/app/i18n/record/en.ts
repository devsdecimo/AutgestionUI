const recordEN = {
    recordButton: 'Record',
    identificationButton: 'Identifications',
    referencesButton: 'References',
    maintitle: 'Record\'s information',
    recordNumber: 'Record Number',
    employeeCode: 'Employee Code',
    openingDate: 'Opening Date',
    recordState: 'Record State',
    employeeName: 'Employee Name',
    identification: 'Identification',
    civilStatus: 'Civil Status',
    citizenship: 'Citizenship',
    phoneNumber: 'Phone Number',
    mobilePhoneNumer: 'Mobile Phone Number',
    address: 'Address',
    email: 'Email',
  };
  
  export default recordEN;