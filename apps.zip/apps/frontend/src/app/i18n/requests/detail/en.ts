const requestDetailEN = {
    mainTitle: 'My Requests',
    searchOptions: 'Search Options',
    reason: 'Reason',
    requestNumberFilter: 'Request Number',
    registerDate: 'Register Date',
    state: 'State',
    closed: 'Closed',
    opened: 'Opened',
    search: 'Search',
    send: 'Send',
    message: 'Message',
    description: 'Description',

}

export default requestDetailEN;
