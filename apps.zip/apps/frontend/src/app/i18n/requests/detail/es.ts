const requestDetailES = {
    mainTitle: 'Mis gestiones',
    searchOptions: 'Opciones de Búsqueda',
    reason: 'Motivo',
    requestNumberFilter: 'Núero de Gestión',
    registerDate: 'Fecha Registro',
    state: 'Estado',
    closed: 'Cerrado',
    opened: 'Abierto',
    search: 'Buscar',
    send: 'Enviar',
    message: 'Mensaje',
    description: 'Descripción',
}

export default requestDetailES;
