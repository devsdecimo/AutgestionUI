const requestsEN = {
    mainTitle: 'My Requests',
    searchOptions: 'Search Options',
    reason: 'Reason',
    requestNumberFilter: 'Request Number',
    registerDate: 'Register Date',
    state: 'State',
    closed: 'Closed',
    opened: 'Opened',
    search: 'Search',
    requestNumberTable: 'Request Number',
    register: 'Register',
    details: 'Details',
    viewMore: 'View More',

}

export default requestsEN;