const requestsES = {
    mainTitle: 'Mis gestiones',
    searchOptions: 'Opciones de Búsqueda',
    reason: 'Motivo',
    requestNumberFilter: 'Núero de Gestión',
    registerDate: 'Fecha Registro',
    state: 'Estado',
    closed: 'Cerrado',
    opened: 'Abierto',
    search: 'Buscar',
    requestNumberTable: 'No. Gestión',
    register: 'Registro',
    details: 'Detalles',
    viewMore: 'Ver Más',

}

export default requestsES;