const salaryDetailES = {
  titles: {
    payrollIncome: 'Ingresos Nómina: PERIODO DEL ',
    payrollTo: ' AL ',
    deductions: 'Deducciones',
    net: 'Neto'
  },
  headers: {
    concept: 'Concepto',
    calculationBasis: 'Base de Cálculo',
    income: 'Ingreso',
    deduction: 'Deducción',
    totalDeductions: 'Total Deducciones',
    totalIncomes: 'Total Ingresos',
    net: 'Neto'
  }
};

export default salaryDetailES;
