const salariesEN = {
  title: 'My Salaries',
  searchOptions: 'Search Options',
  period: 'Period',
  startDate: 'Start Date',
  endDate: 'End Date',
  selectAnOption: 'Select an Option',
  search: 'Search',
  download: 'Download',
  seeMore: 'See More',
};

export default salariesEN;
