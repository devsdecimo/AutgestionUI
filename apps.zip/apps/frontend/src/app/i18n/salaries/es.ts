const salariesES = {
  title: 'Mis Salarios',
  searchOptions: 'Opciones de Búsqueda',
  period: 'Periodo',
  startDate: 'Fecha Inicial',
  endDate: 'Fecha Final',
  selectAnOption: 'Seleccionar una Opción',
  search: 'Buscar',
  download: 'Descargar',
  seeMore: 'Ver Más',
};

export default salariesES;
