const timeEN = {
    timeRegistration: 'Time Registration',
    timeRecordQuery: 'Time Records Query',
    checkIn: 'Check In',
    checkOut: 'Check Out',
}

export default timeEN;