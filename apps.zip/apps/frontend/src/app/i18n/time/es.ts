const timeES = {
    timeRegistration: 'Registro de tiempo',
    timeRecordQuery: 'Consulta Registros de Tiempo',
    checkIn: 'Entrada',
    checkOut: 'Salida',
}

export default timeES;