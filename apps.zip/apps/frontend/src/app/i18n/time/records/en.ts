const timeRecordsEN = {
    timeRegistration: 'Time Registration',
    timeRecordQuery: 'Time Records Query',
    mainTitle: 'Time Records Query',
    searchOptions: 'Search Options',
    state: 'State',
    checkIns: 'Check Ins',
    checkOuts: 'Check Outs',
    startDate: 'Start Date',
    endDate: 'End Date',
    employeeName: 'Employee Name',
    search: 'Search',
    markDate: 'Mark Date',
    markTime: 'Mark Time',
    markType: 'Mark Type',
    location: 'Location',
}

export default timeRecordsEN;