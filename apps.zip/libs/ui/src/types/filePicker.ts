export type FilePickerProps = {
  boxLabel?: string;
  cancelBtnLabel?: string;
  saveBtnLabel?: string;
  fileLabel?: string;
  stateLabel?: string;
  uploadFileLabel?: string;
  alertSuccessTitle?: string;
  alertSuccessText?: string;
}
