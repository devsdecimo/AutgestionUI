export default ['**/*/vite.config.ts', '**/*/vitest.config.ts'];
